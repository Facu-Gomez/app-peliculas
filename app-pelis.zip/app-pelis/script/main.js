new Vue({
  el: '#app',
  data: {
    movies: [],
    favorites: [],
    mostrarFavoritas: false,
    mostrarDetalles: false,
    detallePelicula: {},
    search: {
      movies: [],
      originalMovies: [],
      busqueda: '',
      generoSeleccionado: ''
    },
  },
  mounted() {
    this.fetchPeliculas();
    this.loadFavoritesFromLocalStorage(); 
  },
  methods: {
    fetchPeliculas() {
      fetch('./pelis.json')
        .then(response => response.json())
        .then(data => {
          this.movies = data.peliculas;
          this.search.originalMovies = data.peliculas; 
        })
        .catch(error => {
          console.error('Error al obtener los datos del JSON:', error);
        });
    },
    mostrarFavoritos() {
      this.mostrarFavoritas = true;
    },
    loadFavoritesFromLocalStorage() {
      const favorites = localStorage.getItem('favorites');
      if (favorites) {
        this.favorites = JSON.parse(favorites);
      }
    },
    saveFavoritesToLocalStorage() {
      localStorage.setItem('favorites', JSON.stringify(this.favorites));
    },
    realizarBusqueda() {
      const busqueda = this.search.busqueda.toLowerCase();
      const genero = this.search.generoSeleccionado.toLowerCase();

      if (busqueda === '' && genero === '') {
        this.movies = this.search.originalMovies;
      } else {
        this.movies = this.search.originalMovies.filter(movie => {
          const titulo = movie.titulo.toLowerCase();
          const movieGenero = movie.genero.toLowerCase();

          return (titulo.includes(busqueda) && movieGenero.includes(genero)) ||
            (titulo.includes(busqueda) && genero === '') ||
            (busqueda === '' && movieGenero.includes(genero));
        });
      }
    },
    agregarFavorito(movie) {
      const existe = this.favorites.some(favorite => favorite.titulo === movie.titulo);
      if (!existe) {
        this.favorites.push(movie);
        this.saveFavoritesToLocalStorage();
      }
    },
    verDetalles(movie) {
      this.detallePelicula = movie;
      this.mostrarDetalles = true;
    },
    ocultarDetalles() {
      this.mostrarDetalles = false;
    },
    ocultarModal() {
      this.mostrarFavoritas = false;
    },
    eliminarFavorito(movie) {
      const index = this.favorites.findIndex(favorite => favorite.titulo === movie.titulo);
      if (index !== -1) {
        this.favorites.splice(index, 1);
        this.saveFavoritesToLocalStorage();
      }
    },
  },
  filters: {
    truncateText(text, length) {
      if (text.length > length) {
        return text.substring(0, length) + '...';
      }
      return text;
    }
  }
});
