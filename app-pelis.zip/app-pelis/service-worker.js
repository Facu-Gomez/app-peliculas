const cacheName = 'peliculas';
const assets    = [
    'index.html',
    'bootstrap-5.3.0-dist/css/bootstrap-5.3.0-dist/css/bootstrap.min.css', 
    'bootstrap-5.3.0-dist/js/bootstrap-5.3.0-dist/js/bootstrap.min.js',
    'css/estilo.css',
    'https://cdn.jsdelivr.net/npm/vue',
    'https://cdn.jsdelivr.net/npm/vue@2.6.14',
    'script/main.js',  
    'img/elresplandor.jpg',
    'img/eterno.jpg',
    'img/forest.jpg',
    'img/milesmorales.jpg',
    'img/orgullo.jpg',
    'img/padrino.jpg',
    'img/pulp.jpg',
    'img/senor.jpg',
    'img/thegrinch.jpg',
    'img/truman.jpg'
];


self.addEventListener('install', event => {
   console.log('el sw se instalo');

    self.skipWaiting();

    event.waitUntil(
        caches.open(cacheName)
                .then(objCache => {
                    objCache.addAll(assets);
        })
    );
} )

self.addEventListener('fetch', event =>{
    console.log(event);


    event.respondWith(
        //Aca adentro construimos la respuesta
        //Paso 1: nos fijamos si lo que se pide esta en el cache del service worker.
        caches.match(event.request)
                .then(respuesta => {
                    if(respuesta){
                        //Encontramos el recurso solicitado en cache
                        return respuesta;
                    };

                    //Si llego a este punto es porque no lo encontro
                    console.log('No esta en cache', event.request);

                    //Paso 2: hacemos un clon del request
                    let requestToCache = event.request.clone();

                    return fetch(requestToCache)
                            .then(respuesta => {
                                if(!respuesta || respuesta.status != 200){
                                    console.log('ERROR');
                                    //Aca debemos costruir una respuesta amigable
                                    return respuesta;
                                }
                                //Si llego hasta aca, significa que pudimos obtener el recurso
                                //Paso 3: Hacemos un clon de la respeusta 
                                let responseToCache = respuesta.clone();
                                //Paso 4: guardamos la respuesta en cache
                                caches.open(cacheName)
                                       .then(cache => {
                                        console.log(requestToCache);
                                        console.log(responseToCache);
                                        cache.put(requestToCache, responseToCache);
                                       })
                                //La interfaz sigue esperando una respuesta 
                                return respuesta;
                            })
                            .catch(error => {
                                console.log('error', error);
                            })
                })
    );

})

self.addEventListener('activate', event => {
    console.log('el sw se activo');
} ) 

